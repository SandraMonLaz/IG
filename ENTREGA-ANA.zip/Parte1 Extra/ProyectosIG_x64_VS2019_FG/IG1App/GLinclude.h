#pragma once

#include <Windows.h>
// una de las siguientes dos l�neas seg�n la organizaci�n del proyecto
//#include <glad.h> // OpenGL Loader Generator
//#include �glad.h� // OpenGL Loader Generator
#include "glad.h"											//EXTRA 2
#include <GL/freeglut.h> // OpenGL Utility Toolkit	     	//EXTRA 2
#include <glm.hpp> // OpenGL Mathematics